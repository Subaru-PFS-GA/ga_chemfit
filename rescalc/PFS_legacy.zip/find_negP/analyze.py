import glob, os
import numpy as np

output = glob.glob('*.out')
basedir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/ATLAS/'

found = []

for filename in output:
    f = open(filename, 'r')
    content = f.read()
    f.close()
    if content.find('Done!') == -1:
        raise ValueError('Incomplete run')
    found += content.strip().split()[:-1]

results = {}

for model in found:
    model, status = model.split('|')
    if status not in results:
        results[status] = []
    results[status] += [model]

all = []
for status in results:
    print(status, len(results[status]))
    all += results[status]

np.savetxt('../broken_spectra.dat', all, fmt = '%s')
