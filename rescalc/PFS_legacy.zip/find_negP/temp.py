import numpy as np

found = np.loadtxt('found.dat', dtype = str)
errors = np.loadtxt('errors.dat', dtype = str)

print(found[~np.in1d(found, errors)])
