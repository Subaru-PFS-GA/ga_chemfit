import numpy as np
import os

template = """
#!/bin/bash
#SBATCH --partition=shared
#SBATCH --account=csd835
#SBATCH --job-name="{jobname}"
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --mem=2000M
#SBATCH -t 10:00:00
#SBATCH --output="{output}"
#SBATCH --export=ALL

python <<EOF

import numpy as np
import pickle
import os

basedir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/ATLAS/'
resultsdir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/results/'
models = np.load('/home/rgerasim/chemfit/rescalc/find_negP/models.npy')

for model in models[{start}:{end}]:
    # file = open(basedir + model + '/output_summary.out', 'r')
    # data = file.read()
    # file.close()
    # data = data[data.rfind('RHOX'):data.rfind('PRADK')]
    # data = data.replace('E-', 'E=').replace('-', ' -').replace('E=', 'E-')
    # data = np.loadtxt(data.split('\\n'), unpack = True, skiprows = 1)
    # if np.min(data[2]) < 0 or np.min(data[0]) < 0:
    #     print(model)
    if not os.path.isfile(basedir + model + '/response.pkl'):
        print('{{}}|not_found'.format(model))
        continue
    try:
        f = open(basedir + model + '/response.pkl', 'rb')
        response = pickle.load(f)
        f.close()
    except:
        print('{{}}|corrupted'.format(model))
        continue
    if np.any(np.isnan(response['null']['line'])):
        print('{{}}|nan'.format(model))
        continue

    if np.max(response['null']['line']) > 1.02:
        print('{{}}|emission'.format(model))
        continue

    if np.max(response['null']['line']) > 2:
        print('{{}}|superemission'.format(model))
        continue

    if np.min(response['null']['line']) < 0:
        print('{{}}|negative'.format(model))
        continue

print('Done!')

EOF
""".strip()

batch_size = 10000

models = np.load('find_negP/models.npy')
chunks = [(i, min(i + batch_size, len(models))) for i in range(0, len(models), batch_size)]

for i, chunk in enumerate(chunks):
    f = open('find_negP/batch_{}.tqs'.format(i), 'w')
    f.write(template.format(jobname = 'find_negP_{}'.format(i), output = os.path.realpath('find_negP/batch_{}.out'.format(i)), start = chunk[0], end = chunk[1]))
    f.close()

