import numpy as np
import os
import tqdm
import pickle
import shutil

basedir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/'

broken_spectra = np.loadtxt('broken_spectra.dat', dtype = str)

stats = {'missing': 0, 'nan': 0, 'negative': 0, 'superemission': 0, 'emission': 0}

to_fix = []

for model in tqdm.tqdm(broken_spectra):
    if not os.path.isfile(basedir + '/ATLAS/{}/response.pkl'.format(model)):
        stats['missing'] += 1
        to_fix += [model]
        print(model)
        continue

    f = open(basedir + '/ATLAS/{}/response.pkl'.format(model), 'rb')
    response = pickle.load(f)
    f.close()

    if np.any(np.isnan(response['null']['line'])):
        stats['nan'] += 1
        to_fix += [model]
        continue

    if np.min(response['null']['line']) < 0:
        stats['negative'] += 1
        to_fix += [model]
        continue

    if np.max(response['null']['line']) > 1.1:
        stats['superemission'] += 1
        to_fix += [model]
        continue

    if np.max(response['null']['line']) > 1.02:
        stats['emission'] += 1
        continue

print(stats)

proceed = False

if proceed:

    for model in tqdm.tqdm(to_fix):
        # Remove result report
        if os.path.isfile(filename := (basedir + '/results/{}_complete'.format(model))):
            os.remove(filename)
        if os.path.isfile(filename := (basedir + '/results/{}_incomplete'.format(model))):
            os.remove(filename)

        # Add the current structure to the list of forbidden structures
        if not os.path.isdir(fbddir := (basedir + '/ATLAS_forbidden_structures/{}'.format(model))):
            os.mkdir(fbddir)
        i = 1
        while os.path.isfile(fbdfn := (fbddir + '/{}.out'.format(i))):
            i += 1
        shutil.copy(basedir + '/ATLAS/{}/output_last_iteration.out'.format(model), fbdfn)

    np.savetxt('/home/rgerasim/chemfit/rescalc/find_negP/found.dat', to_fix, fmt = '%s')
