import os

basedir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/results/'
results = os.listdir(basedir)

results = [result for result in results if result.split('_')[-1] == 'incomplete']

print('Found: {}'.format(len(results)))

for result in results:
    os.remove(basedir + result)

