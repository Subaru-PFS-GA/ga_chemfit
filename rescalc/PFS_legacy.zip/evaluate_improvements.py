import atlas
import os
import tqdm
import numpy as np

ATLAS_dir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/ATLAS/'
output_dir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/ATLAS_improved/'

models = os.listdir(output_dir)

tally = {'none': 0, 'up_0': 0, 'up_1': 0, 'up_2': 0, 'up_3': 0, 'total': 0}

def cclass(conv):
    if conv[0] < 1 and conv[1] < 10:
        return 3
    elif conv[0] < 10 and conv[1] < 100:
        return 2
    elif conv[0] < 1000:
        return 1
    else:
        return 0

for model in tqdm.tqdm(models):
    tally['total'] += 1

    if os.path.isfile(output_dir + model):
        tally['none'] += 1
        continue

    structure = atlas.read_structure(ATLAS_dir + model)[0]
    original_conv = [np.max(np.abs(structure['flux_error'])), np.max(np.abs(structure['flux_error_derivative']))]
    structure = atlas.read_structure(output_dir + model)[0]
    new_conv = [np.max(np.abs(structure['flux_error'])), np.max(np.abs(structure['flux_error_derivative']))]
    improvement = cclass(new_conv) - cclass(original_conv)
    assert improvement >= 0
    tally['up_{}'.format(improvement)] += 1

print('No improvement: {none} | Same class: {up_0} | Up 1 class: {up_1} | Up 2 classes: {up_2} | Up 3 classes: {up_3} | Total: {total}'.format(**tally))
