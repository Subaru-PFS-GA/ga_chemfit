import os
import numpy as np
import griddef
import tqdm
import pickle


ATLAS_dir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/ATLAS/'
ODF_dir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/ODF/'
results_dir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/results/'
output_dir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/ATLAS_improved/'
scripts_dir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/scripts/'

expected_total = 1806420

template = """
import atlas, os
import numpy as np
import shutil

import warnings
warnings.filterwarnings('ignore')

original = '{original}'
print('*** Trying to improve {{}} ***'.format(original))
work_dir = os.path.expandvars('{work_dir}')
ODF = '{ODF}'
candidates = {candidates}
output_dir = '{output_dir}'

while original[-1] == '/':
    original = original[:-1]

meta = atlas.meta(original)
structure = atlas.read_structure(original)[0]
original_conv = [np.max(np.abs(structure['flux_error'])), np.max(np.abs(structure['flux_error_derivative']))]
if original_conv[0] < 1 and original_conv[1] < 10:
    original_cclass = 3
elif original_conv[0] < 10 and original_conv[1] < 100:
    original_cclass = 2
elif original_conv[0] < 1000:
    original_cclass = 1
else:
    original_cclass = 0

print('Original convergence:', original_conv, original_cclass)

conv = []
run_dirs = []
conv_class = []
for candidate in candidates:
    while candidate[-1] == '/':
        candidate = candidate[:-1]
    run_dir = work_dir + '/{{}}/{{}}'.format(os.path.basename(candidate), os.path.basename(original))
    run_dirs += [run_dir]
    os.makedirs('/'.join(run_dir.split('/')[:-1]), exist_ok = True)
    settings = atlas.Settings()
    settings.teff = meta['teff']
    settings.logg = meta['logg']
    settings.abun = meta['abun']
    settings.zscale = np.round(meta['zscale'], 2)
    settings.Y = np.round(meta['Y'], 3)
    print('>>> Restarting from {{}} <<<'.format(candidate))
    try:
        atlas.atlas(run_dir, settings = settings, ODF = ODF, restart = candidate)
    except Exception as e:
        if e.args[0].find('diverged immediately') != -1:
            shutil.rmtree(run_dir)
            print('>>> Model diverged immediately <<<')
            conv += [[1e99, 1e99]]
            continue
        else:
            raise
    os.remove('{{}}/odf_1.ros'.format(run_dir))
    os.remove('{{}}/odf_9.bdf'.format(run_dir))
    structure = atlas.read_structure(run_dir)[0]
    conv += [[np.max(np.abs(structure['flux_error'])), np.max(np.abs(structure['flux_error_derivative']))]]

cclass = []
for errors in conv:
    if errors[0] < 1 and errors[1] < 10:
        cclass += [3]
    elif errors[0] < 10 and errors[1] < 100:
        cclass += [2]
    elif errors[0] < 1000:
        cclass += [1]
    else:
        cclass += [0]
cclass = np.array(cclass)
conv = np.array(conv).T
run_dirs = np.array(run_dirs)
print('Attempts', conv.T, cclass)
better = (cclass >= original_cclass) & (conv[0] < original_conv[0])
if np.count_nonzero(better) != 0:
    better = better & (cclass == np.max(cclass[better]))
    best = run_dirs[better][np.argmin(conv[0][better])]
    print('Best: ', best)
    shutil.copytree(str(best), str(output_dir + os.path.basename(best)))
else:
    print('Cannot improve')
    f = open(output_dir + os.path.basename(original), 'w')
    f.close()
print(flush = True)
""".strip()

available_ATLAS = os.listdir(ATLAS_dir)
available_results = os.listdir(results_dir)
convergence = {}
for result in available_results:
    if result[-7:] == '_failed':
        raise ValueError('Failed model')
    else:
        convergence['_'.join(result.split('_')[:-2])] = [result, np.array(result.split('_')[-2:]).astype(float)]

assert len(available_ATLAS) == expected_total
assert len(convergence) == expected_total

griddef.teff = np.unique(griddef.teff)
griddef.logg = np.unique(griddef.logg)
griddef.zscale = np.unique(griddef.zscale)
griddef.alpha = np.unique(griddef.alpha)

# Convert model parameters into 5D grid point coordinates
coords = []
all_errors = []
cclass = []
filename = []
for conv in tqdm.tqdm(convergence):
    filename += [conv]
    errors = convergence[conv][1]
    conv = conv.split('_')
    teff = np.where(griddef.teff == float(conv[-2]))[0][0]
    logg = np.where(griddef.logg == float(conv[-1]))[0][0]
    zscale = np.where(griddef.zscale == float(conv[0][1:]))[0][0]
    alpha = np.where(griddef.alpha == float(conv[1][1:]))[0][0]
    carbon = np.round([griddef.interpolator([float(conv[0][1:]), float(conv[-1]), i])[0] + 0.0001 for i in np.arange(-2, 3)], 1)
    carbon = np.where(np.unique(carbon) == float(conv[2][1:]))[0][0]
    if errors[0] < 1 and errors[1] < 10:
        cclass += [3]
    elif errors[0] < 10 and errors[1] < 100:
        cclass += [2]
    elif errors[0] < 1000:
        cclass += [1]
    else:
        cclass += [0]
    coords += [[teff, logg, zscale, alpha, carbon]]
    all_errors += [errors]

cclass = np.array(cclass)
coords = np.array(coords)
filename = np.array(filename)
all_errors = np.array(all_errors)

# import pickle
# f = open('dump.pkl', 'rb')
# cclass, coords, filename, all_errors = pickle.load(f)
# f.close()


def get_cclass(conv):
    if conv[0] < 1 and conv[1] < 10:
        return 3
    elif conv[0] < 10 and conv[1] < 100:
        return 2
    elif conv[0] < 1000:
        return 1
    else:
        return 0

existing = set(os.listdir(output_dir))

f = open('accepted.pkl', 'rb')
accepted = set(pickle.load(f))
f.close()

# Determine candidate restarts
for i in tqdm.tqdm(np.arange(len(cclass))[cclass != 3]):
    if filename[i] in existing:
        continue

    # Find suitable restarts
    restarts = (np.sum(np.abs(coords - coords[i]), axis = 1) == 1) & (cclass > 1) & (cclass > cclass[i]) # & (coords.T[0] - coords[i,0] != 1)
    restarts[restarts] &= np.array([value in accepted for value in filename[restarts]]).astype(bool)

    if np.count_nonzero(restarts) == 0:
        continue

    restart_cclass = np.array([get_cclass(errors) for errors in all_errors[restarts]])
    priorities = np.argsort(np.lexsort((all_errors[restarts,0], -restart_cclass)))

    # Generate run script
    f = open('{}/{}.py'.format(scripts_dir, filename[i]), 'w')
    candidates = ['{}/{}'.format(ATLAS_dir, candidate) for candidate in filename[restarts]]
    candidates = '[\'' + '\', \''.join(candidates) + '\']'
    f.write(template.format(original = '{}/{}'.format(ATLAS_dir, filename[i]), work_dir = '/scratch/$USER/job_$SLURM_JOB_ID/{}'.format(filename[i]), ODF = '{}/{}'.format(ODF_dir, '_'.join(filename[i].split('_')[:-2])), candidates = candidates, output_dir = output_dir))
    f.close()
