import os, tqdm
import atlas
import numpy as np
import shutil
import pickle

basedir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/ATLAS_improved/'
ATLAS_dir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/ATLAS/'
results_dir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/results/'
models = os.listdir(basedir)

def get_cclass(conv):
    if conv[0] < 1 and conv[1] < 10:
        return 3
    elif conv[0] < 10 and conv[1] < 100:
        return 2
    elif conv[0] < 1000:
        return 1
    else:
        return 0

accepted = []
results = os.listdir(results_dir)

for model in tqdm.tqdm(models):
    if os.path.isfile(basedir + model):
        os.remove(basedir + model)
        continue
    conv_new = atlas.read_structure(basedir + model)[0]
    conv_new = np.max(np.abs(conv_new['flux_error'])), np.max(np.abs(conv_new['flux_error_derivative']))
    message = '{}_{}_{}'.format(model, *conv_new)
    os.remove(results_dir + [result for result in results if result.find(model) == 0][0])
    f = open(results_dir + message, 'w'); f.close()

    shutil.rmtree(ATLAS_dir + model)
    os.rename(basedir + model, ATLAS_dir + model)
    accepted += [model]

f = open('accepted.pkl', 'wb')
pickle.dump(accepted, f)
f.close()
