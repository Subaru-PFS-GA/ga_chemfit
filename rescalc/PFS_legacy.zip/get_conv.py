import os
import numpy as np

ATLAS_dir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/ATLAS/'
results_dir = '/expanse/lustre/projects/csd835/rgerasim/pfsgrid/results/'

expected_total = 1806420

available_ATLAS = os.listdir(ATLAS_dir)
available_results = os.listdir(results_dir)
convergence = {}
for result in available_results:
    if result[-7:] == '_failed':
        raise ValueError('Failed model')
    else:
        convergence['_'.join(result.split('_')[:-2])] = [result, np.array(result.split('_')[-2:]).astype(float)]

assert len(available_ATLAS) == expected_total
assert len(convergence) == expected_total

gold = 0; silver = 0; bronze = 0; unconv = 0

for conv in convergence:
    conv = convergence[conv]
    if conv[1][0] < 1 and conv[1][1] < 10:
        gold += 1
    elif conv[1][0] < 10 and conv[1][1] < 100:
        silver += 1
    elif conv[1][0] < 1000:
        bronze += 1
    else:
        unconv += 1

print('gold: {} | silver: {} | bronze: {} | unconv: {} | total: {} | G+S: {}'.format(gold, silver, bronze, unconv, total := (gold + silver + bronze + unconv), (gold + silver) / total * 100))
